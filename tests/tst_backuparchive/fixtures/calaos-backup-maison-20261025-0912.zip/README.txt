Calaos backup: io.xml and rules.xml are your home, local_config.xml the settings of the box.
It contains passwords: the household login, tokens, mail and InfluxDB passwords. local_config.xml
also holds the ddns token, which lets anyone delete your calaos.fr address. Keep this backup private.
To restore it, one of:
1. Web app: Admin, Settings, "Restore a backup...", then pick this zip.
2. Calaos Installer: unzip, "Open project" on the folder, "Send project to Calaos Server"
   (io.xml and rules.xml only).
3. SSH: unzip, systemctl stop calaos-server, scp io.xml rules.xml local_config.xml
   root@<box>:/mnt/calaos/config/, systemctl start calaos-server.

Sauvegarde Calaos : io.xml et rules.xml sont votre maison, local_config.xml les réglages de la box.
Elle contient des mots de passe : foyer, jetons, mail et InfluxDB. local_config.xml contient aussi
le jeton ddns, qui permet à n'importe qui de supprimer votre adresse calaos.fr. Gardez-la privée.
Pour la restaurer : application web (Admin, Réglages, « Restaurer une sauvegarde… »), Calaos
Installer (décompresser, ouvrir le dossier, envoyer le projet) ou SSH (comme ci-dessus).
